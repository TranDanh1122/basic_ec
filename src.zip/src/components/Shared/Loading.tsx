import React from "react";
const Loading = React.memo(() => {
    return <div className="loader"></div> 
})
Loading.displayName = "Loading"
export default Loading